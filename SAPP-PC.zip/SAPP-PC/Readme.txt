SAPP-PC
90 instances are provided, 30 instances for small size, 30 instances for medium size, and 30 instances for large size.  5 different instances are provided for each combination of numbers of assets, vehicles, main depots, and scenarios. 
For example the parameter corresponding to the first instance with 20 assets, 3 main depots, 2 backup depots, 5 vehicles and 10 scenarios is reported in folder named by ins1-20-2-3-5-10.
